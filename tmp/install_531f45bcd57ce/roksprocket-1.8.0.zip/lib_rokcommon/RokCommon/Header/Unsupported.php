<?php
 /**
  * @version   $Id: Unsupported.php 57540 2012-10-14 18:27:59Z btowles $
  * @author    RocketTheme http://www.rockettheme.com
  * @copyright Copyright (C) 2007 - ${copyright_year} RocketTheme, LLC
  * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
  */
 
class RokCommon_Header_Unsupported extends RokCommon_Header_AbstractHeader
{

}
